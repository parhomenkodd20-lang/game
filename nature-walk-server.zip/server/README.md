# Nature Walk — сервер

Заменяет "хозяина"-игрока на всегда включённый сервер и хранит одно сохранение мира.

## Запуск на Render
1. Создать Web Service из этого репозитория.
2. Build Command: `npm install`
3. Start Command: `npm start`
4. Environment: Node
5. (Автоматически) Render даст переменную PORT — сервер её уже читает.

## Локальная проверка (не обязательно)
```
npm install
npm start
```
