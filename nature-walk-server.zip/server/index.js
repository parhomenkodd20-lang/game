// Простой сервер для Nature Walk: всех соединяет между собой (вместо PeerJS-хозяина)
// и хранит одно "текущее" сохранение мира на диске — без накопления старых версий.
import { WebSocketServer } from 'ws';
import { readFile, writeFile, rename, mkdir } from 'fs/promises';
import { createServer } from 'http';

const PORT = process.env.PORT || 3000;
const SAVE_DIR = process.env.SAVE_DIR || './saves';
const SAVE_FILE = SAVE_DIR + '/world.json';
const SAVE_TMP = SAVE_DIR + '/world.json.tmp';

// ---------- health-check для Render (чтобы сервис считался "живым") ----------
const http = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Nature Walk server OK, players: ' + clients.size);
});
const wss = new WebSocketServer({ server: http });

// ---------- сохранение мира: одна запись, перезаписывается, старые версии не копятся ----------
let world = { buildings: [], resources: {}, nicknames: {} }; // на будущее: постройки/ресурсы уже сюда
let saveTimer = null;
let dirty = false;

async function loadWorld() {
  try {
    const raw = await readFile(SAVE_FILE, 'utf-8');
    world = JSON.parse(raw);
    console.log('Мир загружен из', SAVE_FILE);
  } catch {
    console.log('Сохранения ещё нет, начинаем с пустого мира');
  }
}

async function saveWorldNow() {
  if (!dirty) return;
  dirty = false;
  try {
    await mkdir(SAVE_DIR, { recursive: true });
    await writeFile(SAVE_TMP, JSON.stringify(world));
    await rename(SAVE_TMP, SAVE_FILE); // атомарная замена — файл не битый, даже если сервер упадёт на записи
  } catch (e) {
    console.error('Не удалось сохранить мир:', e.message);
  }
}

function markDirty() {
  dirty = true;
  if (!saveTimer) saveTimer = setTimeout(() => { saveTimer = null; saveWorldNow(); }, 5000); // не чаще раза в 5с
}

// ---------- игроки ----------
const clients = new Map(); // id -> ws
let nextId = 1;

function send(ws, obj) { try { ws.send(JSON.stringify(obj)); } catch {} }
function broadcast(obj, exceptId) {
  const s = JSON.stringify(obj);
  for (const [id, ws] of clients) {
    if (id === exceptId) continue;
    try { ws.send(s); } catch {}
  }
}

wss.on('connection', (ws) => {
  const id = 'p' + (nextId++);
  clients.set(id, ws);
  send(ws, { t: 'welcome', id, world });               // новичку — его id и текущий мир
  broadcast({ t: 'join', id }, id);                     // остальным — что кто-то пришёл

  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object') return;

    if (m.t === 'ping') { send(ws, { t: 'pong' }); return; }

    // Сохранение мира: клиент присылает изменения, сервер их запоминает и планирует запись на диск
    if (m.t === 'world') {
      if (m.buildings) world.buildings = m.buildings;
      if (m.resources) world.resources = m.resources;
      if (m.nicknames) world.nicknames = m.nicknames;
      markDirty();
      return; // остальным мир целиком не шлём, он и так у всех есть с момента входа
    }

    // Всё остальное (позиции, удары, чат, сумки) — просто пересылаем другим игрокам,
    // добавляя, от кого сообщение. Это заменяет "хозяина"-браузер из PeerJS.
    m.from = id;
    broadcast(m, id);
  });

  ws.on('close', () => {
    clients.delete(id);
    broadcast({ t: 'leave', id }, id);
  });
});

await loadWorld();
http.listen(PORT, () => console.log('Сервер запущен на порту ' + PORT));

// сохраняемся, если процесс останавливают (Render шлёт SIGTERM при обновлении/перезапуске)
process.on('SIGTERM', async () => { await saveWorldNow(); process.exit(0); });
